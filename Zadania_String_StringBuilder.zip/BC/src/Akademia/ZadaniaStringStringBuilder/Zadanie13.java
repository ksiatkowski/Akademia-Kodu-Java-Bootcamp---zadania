package Akademia.ZadaniaStringStringBuilder;

/* Jaki będzie wynik programu?
   String name = ’’Michał”;
   int a = 0;
   System.out.println(name.charAt(a)); */

public class Zadanie13 {

    public static void main(String[] args) {

        String name = "Michał";
        int a = 0;
        System.out.println(name.charAt(a));
    }
}
