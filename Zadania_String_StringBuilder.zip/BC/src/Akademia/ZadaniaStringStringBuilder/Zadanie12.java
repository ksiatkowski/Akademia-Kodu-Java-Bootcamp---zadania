package Akademia.ZadaniaStringStringBuilder;

/* Odczytaj zdanie zamień małe 'a’ na duże ’A’.
   Użyj replace(). */

import java.util.Scanner;

public class Zadanie12 {

    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);
        System.out.println("Podaj zdanie.");
        String sentence = scanner.nextLine();
        System.out.println();
        System.out.println("A tak ja to widzę: ");
        System.out.println(sentence.replace("a", "A"));

    }
}
