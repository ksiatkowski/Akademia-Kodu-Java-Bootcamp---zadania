package Akademia.ZadaniaStringStringBuilder;

/* Napisz program, który odczytuje kod pocztowy składający się z 5 cyfr.
   Dopisz "-" pomiędzy cyframi. Użyj StringBuilder i insert.

   Dla przykładu:
   87100

   Jako wynik:
   87-100 */

import java.util.Scanner;

public class Zadanie5 {

    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);
        System.out.println("podaj kod pocztowy.");
        String zipCode = scanner.next();

        // sposób 1
        StringBuilder zipBuilder = new StringBuilder(zipCode);
        zipBuilder.insert(2, "-");
        System.out.println("Sposób #1: " + zipBuilder);

        // sposób 2
        System.out.println("Sposób #2: " + zipCode.substring(0, 2) + "-" + zipCode.substring(2));

    }
}
