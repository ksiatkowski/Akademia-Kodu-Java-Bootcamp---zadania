package Akademia.ZadaniaStringStringBuilder;

/* Napisz program, który odczytuje wyraz i sprawdza czy
   wprowadzony wyraz to Akademia. Użyj equalsIgnoreCase(). */

import java.util.Scanner;

public class Zadanie7 {

    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);
        String word = scanner.next();
        System.out.println("Podaj wyraz.");
        if (word.equalsIgnoreCase("akademia")) {
            System.out.println("To jest akademia");
        } else {
            System.out.println("To nie jest akademia");
        }

    }
}
