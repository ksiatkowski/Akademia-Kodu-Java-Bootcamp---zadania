package Akademia.ZadaniaStringStringBuilder;

/* Na serwerze przechowujemy obrazki w formacie:
   http://www.akademiakodu.pl/54/nazwa_panstwa_male_litery.svg
   Odczytaj nazwę państwa zapisaną dużymi literami i na ekran wypisz adres url obrazka.*/

import java.util.Locale;
import java.util.Scanner;

public class Zadanie9 {

    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);
        System.out.println("Podaj nazwę Państwa.");
        String state = scanner.next();
        System.out.println("Adres URL obrazka:");
        System.out.println("http://www.akademiakodu.pl/54/" + state.toLowerCase(Locale.ROOT) + ".svg");

    }
}
