package Akademia.ZadaniaStringStringBuilder;

/* Napisz program, który odczytuje dane w formacie: Imię i Nazwisko Piłkarza Liczba Goli.
   Całość odczytujemy za pomocą nextLine().
   Wypisz tylko nazwisko piłkarza. Użyj indexOf(), substring(). */

import java.util.Scanner;

public class Zadanie8 {

    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);
        System.out.println("Podaj dane piłkarza w formacie: imię nazwisko liczba_goli");

        String data = scanner.nextLine();
        int i = data.indexOf(" ");
        String data2 = data.substring(i + 1);
        int j = data2.indexOf(" ");
        System.out.println(data2.substring(0, j));

    }
}
