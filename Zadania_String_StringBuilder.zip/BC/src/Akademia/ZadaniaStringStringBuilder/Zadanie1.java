package Akademia.ZadaniaStringStringBuilder;

/* Napisz program odczytujący wyraz i wypisujący na ekranie pierwszą literę wyrazu.
   Użyj charAt(). Co się stanie jeśli podamy wyraz pusty? */

import java.util.Scanner;

public class Zadanie1 {

    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);
        System.out.println("Podaj wyraz.");
        String word = scanner.next();
        System.out.println("Pierwsza litera to: " + word.charAt(0) + ".");

    }
}
