package Akademia.ZadaniaStringStringBuilder;

/* Odczytaj wyraz i wypisz na ekran wyraz w odwróconej kolejności.
   Użyj StringBuildera. */

import java.util.Scanner;

public class Zadanie3 {

    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);
        System.out.println("Podaj wyraz.");
        String word = scanner.next();

        StringBuilder wordBuilder = new StringBuilder(word);
        System.out.println("Odwrócony wyraz to: " + wordBuilder.reverse());

    }
}
