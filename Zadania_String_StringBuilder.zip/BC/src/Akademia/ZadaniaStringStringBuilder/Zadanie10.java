package Akademia.ZadaniaStringStringBuilder;

/* Odczytaj nazwę państwa i wypisz tylko 3 pierwsze litery Państwa (na stronie internetowej
   nie mamy więcej miejsca na wyświetlenie). Użyj substring(). */

import java.util.Locale;
import java.util.Scanner;

public class Zadanie10 {

    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);
        System.out.println("Podaj nazwę Państwa.");
        String state = scanner.next();
        System.out.println();
        System.out.println(state.substring(0, 3).toUpperCase(Locale.ROOT));

    }
}
