package Akademia.ZadaniaStringStringBuilder;

/* Odczytaj imię i sprawdź czy imię jest męskie czy żeńskie. Użyj endsWith(). */

import java.util.Scanner;

public class Zadanie2 {

    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);
        System.out.println("Podaj imię.");
        String name = scanner.next();

        // Barnaba --> imię męskie
        // && AND, I; || OR, LUB
        // ! - zaprzeczenie

        if (name.endsWith("a") && !name.equals("Barnaba")) {
            System.out.println("Imie jest żeńskie.");
        } else
            System.out.println("Imię jest męskie.");

    }
}
