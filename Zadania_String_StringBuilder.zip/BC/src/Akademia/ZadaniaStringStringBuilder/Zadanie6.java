package Akademia.ZadaniaStringStringBuilder;

/* Odczytaj zdanie, usuń pierwszy i ostatni znak w zdaniu, wypisz zdanie z usuniętymi znakami. */

import java.util.Scanner;

public class Zadanie6 {

    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);
        System.out.println("Podaj zdanie.");
        String sentence = scanner.nextLine();

        // sposób 1
        int i = sentence.length();
        String sentence2 = sentence.substring(1, i - 1);
        System.out.println();
        System.out.println("Twoje zdanie to: ");
        System.out.println(sentence);
        System.out.println();
        System.out.println("Sposób #1:");
        System.out.println("Twoje zdanie bez pierwszego i ostatniego znaku to: ");
        System.out.println(sentence2);
        System.out.println();
        // sposób 2
        System.out.println("Sposób #2");
        StringBuilder sentence3 = new StringBuilder(sentence);
        System.out.println("Twoje zdanie bez pierwszego i ostatniego znaku to: ");
        System.out.println(sentence3.deleteCharAt(i - 1).deleteCharAt(0));


    }
}
