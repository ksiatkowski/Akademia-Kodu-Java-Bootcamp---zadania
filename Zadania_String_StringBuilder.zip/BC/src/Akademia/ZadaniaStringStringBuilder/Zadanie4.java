package Akademia.ZadaniaStringStringBuilder;

/* Napisz program odczytujący zdanie, sprawdź czy w zdaniu występuje wyraz kot. */

import java.util.Locale;
import java.util.Scanner;

public class Zadanie4 {

    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);
        System.out.println("Podaj zdanie");
        String phrase = scanner.nextLine();
        if (phrase.contains("kot")){
            System.out.println("Zdanie zawiera KOTA.");
        } else
            System.out.println("Zdanie nie zawiera KOTA.");

    }
}
